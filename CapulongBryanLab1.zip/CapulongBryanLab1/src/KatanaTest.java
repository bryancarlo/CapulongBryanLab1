import java.util.Scanner;
public class KatanaTest {

	public static void main(String[] args) {
		
		System.out.println("As the samurai did by tradition, give your new katana a name.");
		Katana myKatana = new Katana();
		Scanner sc = new Scanner(System.in);
				
		String kName = sc.next();
		myKatana.setName(kName);
		System.out.println("\nCurrently it has a blade length of " + myKatana.getBladeLength() +
		", sharpness of " + myKatana.getSharpness() + " and blade hardness of " + myKatana.getHardness() + ".");
		
		boolean willDo = true;
		String yn = "";
		String target1 = "Training Post";
		int numOfSlashes;
		
		System.out.println("\nTest the strength and efficiency of " + myKatana.getName() + " by hitting this " + target1);
		System.out.println("NOTE: Katana sharpness and hardness goes down with each hit."
				+ " By sharpness <= 15, it starts to take double damage.\nDO NOT let it reach hardness 0 or it will BREAK.");
		myKatana.sheath();
		
		System.out.println("\nNOTE: Feel free to hit the " + target1 + " as many times as you want."
				+ "\nBut make sure the katana does not lose too much sharpness and hardness!");
		
		do {
			
			if (myKatana.getSharpness() <= 0) {
				System.out.println("\nAUTO ASSIST: Katana blade has become blunt, sharpening now!");
				myKatana.sharpenBlade();
			}
					
			//slice
			System.out.print("\nYou: How many hits should I do?");
			numOfSlashes = sc.nextInt();
			myKatana.slice(target1, numOfSlashes);
			
			
			if (myKatana.getHardness() <= 0) {
				System.out.println("Blade hardness reduced to 0. YOU BROKE " + myKatana.getName() + "!");
				willDo = false;
				break;
			} else if (myKatana.getSharpness() <= 15) {
				boolean willSharpen = false;
				String yesNo = "";
				System.out.print("\nDECIDE: The blade has gotten dull, would you sharpen it for a while? [Y / N]");
				willSharpen = myKatana.decide(yesNo);
				
				if (willSharpen) myKatana.sharpenBlade();
				
			}
			
			System.out.print("\nDECIDE: Want to keep going? [Y / N]");
			willDo = myKatana.decide(yn);
			
		} while (willDo);
		
		if (myKatana.getHardness() <= 0) {
			System.out.println("\nWell you broke your named katana! Watch your sword's hardness and stop the training before it reaches 0.");
		} else {
			System.out.println("\nYou worked hard, samurai. Let the magic smith restore your katana and be ready for more trainings!");
			myKatana.restoreKatana();
		}
		
		System.out.println("\nEnd of training!");
		myKatana.sheath();
	}

}
