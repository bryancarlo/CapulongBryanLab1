import java.util.Scanner;
public class Katana {
	//attributes
	private boolean isSheathed = true;
	private String name; //samurai named their katanas
	private int bladeLength;
	private int sharpness;
	private int bladeHardness;
	
	//constructor
	public Katana() {
			bladeLength = 25;
			sharpness = 70;
			bladeHardness = 60;
			System.out.print ("Type a name to give to your katana.");
	}
	
 	//methods
	public void sheath() {
		if (isSheathed) {
			isSheathed = false;
			System.out.println("\nUNSHEATH: You have drawn out your katana!");
		} else {
			isSheathed = true;
			System.out.println("\nSHEATH: You have sheathed your katana.");
		}
	}
	
	public void setName(String swordName) {
		name = swordName;
		System.out.println("\nAs your sword, " + swordName + ", now is the shelter of your warrior spirit!");
	}
	public String getName() {
		return name;
	}
	
	public int getBladeLength() {
		return bladeLength;
	}
	public void sharpenBlade() {
		if (bladeHardness > 0) {
		sharpness += (int)(Math.random()*30 + 30);
		System.out.println("SHARPENBLADE: The katana's edge has been sharpened to " + sharpness);
		} else {
			System.out.println("SHARPENBLADE: Unable to sharpen, for your Katana blade is broken");
		}
	}
	
	public int getSharpness() {
		return sharpness;
	}
	
	public int getHardness() {
		return bladeHardness;
	}
	
	public void slice(String targetName, int numOfSlashes) {
		if (isSheathed) {
			System.out.println("\nMust unsheath katana to slash the " + targetName);
		} else if (bladeHardness == 0) {
			System.out.println("\nYou cannot slash with a broken blade!");
		} else if (sharpness <= 15) { //11 slashes from 60 sharpness
			System.out.println("\nSLICE: The blade is dull and unable to thoroughly slash the " + targetName);
			sharpness -= (10*numOfSlashes);
			bladeHardness -= (2*numOfSlashes);
			System.out.println("\nThe katana's sharpness reduced to " + sharpness + " and hardness to " + bladeHardness);
			System.out.println("It endures greater damage when the blade has dulled!");
		} else if (sharpness > 15) {
			System.out.println("\nSLICE: The " + targetName + " had been slashed " + numOfSlashes + " times!");
			sharpness -= (5*numOfSlashes);
			bladeHardness -= (1*numOfSlashes);
			System.out.println("The katana's sharpness reduced to " + sharpness + " and hardness to " + bladeHardness);
		}
	}
	
	public void restoreKatana() {
		sharpness = 70;
		bladeHardness = 60;
		System.out.println("RESTOREKATANA: The katana's edge sharpness has been restored to " + sharpness);
		System.out.println("RESTOREKATANA: The katana's blade hardness has been restored to " + bladeHardness);
	}
	
	public boolean decide(String yn) {
		Scanner sc = new Scanner(System.in);
		/*while (!(yn.equalsIgnoreCase("Y")) | !(yn.equalsIgnoreCase("N"))) {
			yn = sc.next();
		if (!(yn.equalsIgnoreCase("Y")) | !(yn.equalsIgnoreCase("N"))) {
				System.out.println("Be decisive! Y or N only!");
				System.out.println("[Y / N]?");
			}
		}*/
		
		while (!yn.equalsIgnoreCase("Y") & !yn.equalsIgnoreCase("N")) {
			yn = sc.next();
			if (!yn.equalsIgnoreCase("Y") & !yn.equalsIgnoreCase("N")) {
				System.out.println("Y or N only! [Y / N]?");
			}
		}
		
		if (yn.equalsIgnoreCase("Y")){
			return true;
		} else {
			return false;
		}
	//end while
	}
}//end class

